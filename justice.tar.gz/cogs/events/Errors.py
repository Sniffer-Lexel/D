import discord, json
from discord.ext import commands
from core import Astroz, Cog, Context

class Errors(Cog):
  def __init__(self, client:Astroz):
    self.client = client

  @commands.Cog.listener()
  async def on_command_error(self, ctx: Context, error):
    with open('ignore.json', 'r') as heck:
      randi = json.load(heck) 
    with open('blacklist.json', 'r') as f:
      data = json.load(f)

    # Skip CommandNotFound errors
    if isinstance(error, commands.CommandNotFound):
      return

    # If the user is blacklisted, send one message in DM and one in server, and do not reply to the command
    if isinstance(error, commands.CheckFailure):
      if str(ctx.author.id) in data["ids"]:
        # DM the user
        try:
          dm_embed = discord.Embed(title="<:Ban:1300389117678325813> Blacklisted", 
                                   description="You are blacklisted from using my commands.\nIf you think this is a mistake, you can appeal in our support server by clicking [here](https://discord.gg/3Khp9KedDq).", 
                                   color=0x00FFCA)
          await ctx.author.send(embed=dm_embed)
        except discord.Forbidden:
          # Handle the case where the bot can't send DMs to the user
          pass

        # Send a message in the server
        server_embed = discord.Embed(title="<:Ban:1300389117678325813> Blacklisted", 
                                     description=f"{ctx.author.mention}, you are blacklisted from using my commands.", 
                                     color=0x00FFCA)
        await ctx.channel.send(embed=server_embed, delete_after=6)
        return  # Prevent further error handling

      # If the command is disabled in the channel
      if str(ctx.channel.id) in randi["ids"]:
        await ctx.reply(f"My commands are disabled in {ctx.channel.mention}.", mention_author=True, delete_after=6)
        return  # Prevent further error handling

    # Handle other errors
    if isinstance(error, commands.MissingRequiredArgument):
      await ctx.send_help(ctx.command)
      ctx.command.reset_cooldown(ctx)
    elif isinstance(error, commands.NoPrivateMessage):
      rafi = discord.Embed(color=0x00FFCA, description="You can't use my commands in DM(s)", timestamp=ctx.message.created_at)
      rafi.set_author(name=f"{ctx.author.name}", icon_url=f"{ctx.author.avatar}")
      rafi.set_thumbnail(url=f"{ctx.author.avatar}")
      await ctx.reply(embed=rafi, delete_after=20)
    elif isinstance(error, commands.TooManyArguments):
      await ctx.send_help(ctx.command)
      ctx.command.reset_cooldown(ctx)
    elif isinstance(error, commands.CommandOnCooldown):
      rafi = discord.Embed(color=0x00FFCA, description=f"<a:crosss:1245701499200344075> | {ctx.author.name} is on cooldown, retry after {error.retry_after:.2f} second(s).", timestamp=ctx.message.created_at)
      rafi.set_author(name=f"{ctx.author}", icon_url=f"{ctx.author.avatar}")
      await ctx.reply(embed=rafi, delete_after=10)
    elif isinstance(error, commands.MaxConcurrencyReached):
      rafi = discord.Embed(color=0x00FFCA, description="<a:crosss:1245701499200344075> | This command is already running, please wait until it finishes.", timestamp=ctx.message.created_at)
      rafi.set_author(name=f"{ctx.author.name}", icon_url=f"{ctx.author.avatar}")
      rafi.set_thumbnail(url=f"{ctx.author.avatar}")
      await ctx.reply(embed=rafi, delete_after=10)
      ctx.command.reset_cooldown(ctx)
    elif isinstance(error, commands.MissingPermissions):
      missing = [perm.replace("_", " ").replace("guild", "server").title() for perm in error.missing_permissions]
      fmt = "{}, and {}".format(", ".join(missing[:-1]), missing[-1]) if len(missing) > 2 else " and ".join(missing)
      rafi = discord.Embed(color=0x00FFCA, description=f"<a:crosss:1245701499200344075> | You lack `{fmt}` permission(s) to run `{ctx.command.name}` command.", timestamp=ctx.message.created_at)
      rafi.set_author(name=f"{ctx.author.name}", icon_url=f"{ctx.author.avatar}")
      rafi.set_thumbnail(url=f"{ctx.author.avatar}")
      await ctx.reply(embed=rafi, delete_after=6)
      ctx.command.reset_cooldown(ctx)
    elif isinstance(error, commands.BadArgument):
      await ctx.send_help(ctx.command)
      ctx.command.reset_cooldown(ctx)
    elif isinstance(error, commands.BotMissingPermissions):
      missing = ", ".join(error.missing_perms)
      await ctx.send(f'| I need the **{missing}** permission(s) to run the **{ctx.command.name}** command!', delete_after=10)
    elif isinstance(error, discord.HTTPException):
      pass  # Handle HTTP errors if necessary
    elif isinstance(error, commands.CommandInvokeError):
      pass  # Handle command invocation errors if necessary
