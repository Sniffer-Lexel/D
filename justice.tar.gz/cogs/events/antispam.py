import discord
from discord.ext import commands
import datetime
import re
import json
from core import Astroz, Cog
from utils.Tools import getConfig


class AntiSpam(Cog):
    def __init__(self, client: Astroz):
        self.client = client
        self.spam_cd_mapping = commands.CooldownMapping.from_cooldown(4, 7, commands.BucketType.member)
        self.spam_punish_cooldown_cd_mapping = commands.CooldownMapping.from_cooldown(1, 10, commands.BucketType.member)

    @commands.Cog.listener()    
    async def on_message(self, message):
      if not message.guild:
        return
      mem = message.author
      invite_regex = re.compile(r"(?:https?://)?discord(?:app)?\.(?:com/invite|gg)/[a-zA-Z0-9]+/?")
      link_regex = re.compile(r"http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+")
      invite_matches = invite_regex.findall(message.content)
      link_matches = link_regex.findall(message.content)
      data = getConfig(message.guild.id)
      antiSpam = data["antiSpam"]
      antiLink = data["antiLink"]
      wled = data["whitelisted"]
      wlrole = data['wlrole']  
      rafi = message.guild.get_member(message.author.id)
      wlroles = message.guild.get_role(wlrole)
      try:
                if antiSpam is True:
                  if mem.guild_permissions.administrator or str(message.author.id) in wled or wlroles in rafi.roles:
                    return
                  bucket = self.spam_cd_mapping.get_bucket(message)
                  retry = bucket.update_rate_limit()

                  if retry:
                    #punish_cd_bucket = self.spam_punish_cooldown_cd_mapping.get_bucket(message)
                 #   if not punish_cd_bucket.update_rate_limit():
                      if data["punishment"] == "kick":
                        now = discord.utils.utcnow()
                        await message.author.timeout(now + datetime.timedelta(minutes=15), reason="B9 Security | Anti Spam")
                        rafi = discord.Embed(color=0x2f3136,description=f"<a:tickkk:1245701493697286179> | Successfully Muted {message.author} For Spamming")
                        rafi.set_author(name=f"{message.author}", icon_url=f"{message.author.avatar}")
                        rafi.set_thumbnail(url =f"{message.author.avatar}")
                        await message.channel.send(embed=rafi)

                      if data["punishment"] == "ban":
                        now = discord.utils.utcnow()
                        await message.author.timeout(now + datetime.timedelta(minutes=15), reason="B9 Security | Anti Spam")
                        rafi1 = discord.Embed(color=0x2f3136,description=f"<a:tickkk:1245701493697286179> | Successfully Muted {message.author} For Spamming")
                        rafi1.set_author(name=f"{message.author}", icon_url=f"{message.author.avatar}")
                        rafi1.set_thumbnail(url =f"{message.author.avatar}")
                        await message.channel.send(embed=rafi1)

                      if data["punishment"] == "none":
                        now = discord.utils.utcnow()
                        await message.author.timeout(now + datetime.timedelta(minutes=15), reason="B9 Security | Anti Spam")
                        rafi2 = discord.Embed(color=0x2f3136,description=f"<a:tickkk:1245701493697286179> | Successfully Muted {message.author} For Spamming")
                        rafi2.set_author(name=f"{message.author}", icon_url=f"{message.author.avatar}")
                        rafi2.set_thumbnail(url =f"{message.author.avatar}")
                        await message.channel.send(embed=rafi2)

                if antiLink is True:
                    if mem.guild_permissions.administrator or str(message.author.id) in wled or wlroles in rafi.roles:
                        return
                    if invite_matches:
                        await message.delete()

                        if data["punishment"] == "kick":
                            await message.author.timeout(now + datetime.timedelta(minutes=15), reason="B9 Security | Anti Discord Invites")
                            rafi3 = discord.Embed(color=0x2f3136,description=f"<a:tickkk:1245701493697286179> | Successfully Muted {message.author} For Sending Discord Server Invites")
                            rafi3.set_author(name=f"{message.author}", icon_url=f"{message.author.avatar}")
                            rafi3.set_thumbnail(url =f"{message.author.avatar}")
                            await message.channel.send(embed=rafi3)

                        if data["punishment"] == "ban":
                            await message.author.timeout(now + datetime.timedelta(minutes=15), reason="B9 Security | Anti Discord Invites")
                            rafi4 = discord.Embed(color=0x2f3136,description=f"<a:tickkk:1245701493697286179> | Successfully Muted {message.author} For Sending Discord Server Invites")
                            rafi4.set_author(name=f"{message.author}", icon_url=f"{message.author.avatar}")
                            rafi4.set_thumbnail(url =f"{message.author.avatar}")
                            await message.channel.send(embed=rafi4)

                        if data["punishment"] == "none":
                             now = discord.utils.utcnow()
                             await message.author.timeout(now + datetime.timedelta(minutes=15), reason="B9 Security | Anti Discord Invites")
                             rafi5 = discord.Embed(color=0x2f3136,description=f"<a:tickkk:1245701493697286179> | Successfully Muted {message.author} For Sending Discord Server Invites")
                             rafi5.set_author(name=f"{message.author}", icon_url=f"{message.author.avatar}")
                             rafi5.set_thumbnail(url =f"{message.author.avatar}")
                             await message.channel.send(embed=rafi5)
                    if link_matches:
                        if data["punishment"] == "kick":
                          await message.author.timeout(now + datetime.timedelta(minutes=15), reason="B9 Security | Anti Link")
                          rafi6 = discord.Embed(color=0x2f3136,description=f"<a:tickkk:1245701493697286179> | Successfully Muted {message.author} For Sending Links")
                          rafi6.set_author(name=f"{message.author}", icon_url=f"{message.author.avatar}")
                          rafi6.set_thumbnail(url =f"{message.author.avatar}") 
                          await message.channel.send(embed=rafi6)



                        if data["punishment"] == "ban":
                          await message.author.timeout(now + datetime.timedelta(minutes=15), reason="B9 Security | Anti Link")
                          rafi7 = discord.Embed(color=0x2f3136,description=f"<a:tickkk:1245701493697286179> | Successfully Muted {message.author} For Sending Links")
                          rafi7.set_author(name=f"{message.author}", icon_url=f"{message.author.avatar}")
                          rafi7.set_thumbnail(url =f"{message.author.avatar}")  
                          await message.channel.send(embed=rafi7)

                        if data["punishment"] == "none":
                          now = discord.utils.utcnow()
                          await message.author.timeout(now + datetime.timedelta(minutes=15), reason="B9 Security | Anti Link")
                          rafi8 = discord.Embed(color=0x2f3136,description=f"<a:tickkk:1245701493697286179> | Successfully Muted {message.author} For Sending Links")
                          rafi8.set_author(name=f"{message.author}", icon_url=f"{message.author.avatar}")
                          rafi8.set_thumbnail(url =f"{message.author.avatar}") 
                          await message.channel.send(embed=rafi8)
                    else:
                      return
      except Exception as error:
                print(error)