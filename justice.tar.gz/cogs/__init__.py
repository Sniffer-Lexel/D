from __future__ import annotations
from core import Astroz

#____________ Commands ___________
from .commands.mod import mod
from .commands.Autorole import autorole
from .commands.Giveaways import giveaway
from .commands.giveaway_task import gwtask
from .commands.help import Help
from .commands.general import General
from .commands.moderation import Moderation
from .commands.anti import Security
from .commands.raidmode import Automod
from .commands.welcome import Welcomer
from .commands.extra import Utility
from .commands.owner import Owner
from .commands.owner1 import owner1
from .commands.role import Server
from .commands.ignore import Ignore
from .commands.List import list
from .commands.serverinfo import Info
from .commands.Afk import afk
from .commands.about import About
from .commands.vcroles import Voice



#____________ Events _____________

from .events.join import Join
from .events.antiban import antiban
from .events.antichannel import antichannel
from .events.antiguild import antiguild
from .events.antirole import antirole
from .events.antibot import antibot
from .events.antikick import antikick
from .events.antiprune import antiprune
from .events.antiwebhook import antiwebhook
from .events.antiping import antipinginv
from .events.antiemostick import antiemostick
from .events.antintegration import antintegration
from .events.antispam import AntiSpam
from .events.autoblacklist import AutoBlacklist
from .events.antiemojid import antiemojid
from .events.antiemojiu import antiemojiu
from .events.Errors import Errors
from .events.on_guild import Guild
from .events.greet2 import greet

##############select menu + button#############

from .commands.anti1 import anti1
from .commands.general1 import general1
from .commands.role1 import role1
from .commands.extra1 import extra1
from .commands.mod1 import mod1
from .commands.welcome1 import welcome1
from .commands.vcrole1 import vcrole1

###############cmnd add################
async def setup(bot: Astroz):
  await bot.add_cog(Help(bot))
  await bot.add_cog(autorole(bot))
  await bot.add_cog(General(bot))
  await bot.add_cog(Moderation(bot))
  await bot.add_cog(Security(bot))
  await bot.add_cog(Automod(bot))
  await bot.add_cog(Welcomer(bot))
  await bot.add_cog(Utility(bot))
  await bot.add_cog(Owner(bot))
  await bot.add_cog(Server(bot))
  await bot.add_cog(Ignore(bot))
  await bot.add_cog(Info(bot))
  await bot.add_cog(list(bot))
  await bot.add_cog(afk(bot))
  await bot.add_cog(owner1(bot))
  await bot.add_cog(giveaway(bot))
  await bot.add_cog(gwtask(bot))
  await bot.add_cog(About(bot))
  await bot.add_cog(mod(bot))
  await bot.add_cog(Voice(bot))
  ############select menu + button###############

  await bot.add_cog(anti1(bot))
  await bot.add_cog(general1(bot))
  await bot.add_cog(mod1(bot))
  await bot.add_cog(extra1(bot))
  await bot.add_cog(role1(bot))
  await bot.add_cog(welcome1(bot))
  await bot.add_cog(vcrole1(bot))
  ###########################events################3

  await bot.add_cog(antiban(bot))
  await bot.add_cog(antichannel(bot))
  await bot.add_cog(antiguild(bot))
  await bot.add_cog(antirole(bot))
  await bot.add_cog(antibot(bot))
  await bot.add_cog(antikick(bot))
  await bot.add_cog(antiprune(bot))
  await bot.add_cog(antiwebhook(bot))
  await bot.add_cog(antipinginv(bot))
  await bot.add_cog(antiemostick(bot))
  await bot.add_cog(antintegration(bot))
  await bot.add_cog(AntiSpam(bot))
  await bot.add_cog(AutoBlacklist(bot))
  await bot.add_cog(antiemojid(bot))
  await bot.add_cog(antiemojiu(bot))
  await bot.add_cog(Guild(bot))
  await bot.add_cog(Errors(bot))
  await bot.add_cog(greet(bot))
  await bot.add_cog(Join(bot))
