import discord
from discord.ext import commands


class extra1(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    """Extra Commands"""
  
    def help_custom(self):
		      emoji = '<:Custom:1300393376788774985>'
		      label = "Extra"
		      description = "Show You Commands Of Extra"
		      return emoji, label, description

    @commands.group()
    async def __Extra__(self, ctx: commands.Context):
        """`botinfo` , `about` , `uptime` , `stats` , `invite` , `vote` , `serverinfo` , `userinfo` , `roleinfo`  , `user` , `role` , `steal` , `ping` , `badges` , `list roles` , `ignore` , `automod` , `antilink` , `antispam` , `greet`, `ticket`"""