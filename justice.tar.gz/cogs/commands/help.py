import discord
from traceback import format_exception
from discord.ext import commands
from difflib import get_close_matches
import io
import textwrap
import datetime
import sys
from contextlib import suppress
from core import Context
from core.Astroz import Astroz
from core.Cog import Cog
from utils.Tools import *
from itertools import chain
import psutil
import time
import datetime
import platform
import os
import logging
import motor.motor_asyncio
from pymongo import MongoClient
import requests
import motor.motor_asyncio as mongodb
from typing import *
from utils import *
import json
from utils import help as vhelp
from utils import Paginator, DescriptionEmbedPaginator, FieldPagePaginator, TextPaginator

from core import Cog, Astroz, Context
from typing import Optional
from discord import app_commands
start_time = time.time()
client = Astroz()
color = 0x41eeee


def datetime_to_seconds(thing: datetime.datetime):
    current_time = datetime.datetime.fromtimestamp(time.time())
    return round(
        round(time.time()) +
        (current_time - thing.replace(tzinfo=None)).total_seconds())

client = Astroz()





class HelpCommand(commands.HelpCommand):
          cooldown_cache = {}

          async def on_help_command_error(self, ctx, error):
              # Define the errors to handle
              damn = [
                  commands.CommandOnCooldown, commands.CommandNotFound,
                  discord.HTTPException, commands.CommandInvokeError
              ]

              if not isinstance(error, tuple(damn)):
                  await self.context.reply(f"Unknown Error Occurred\n{error.original}", mention_author=False)
              else:
                  # Handling CommandOnCooldown error to send only one message per cooldown
                  if isinstance(error, commands.CommandOnCooldown):
                      user_id = str(self.context.author.id)
                      current_time = time.time()

                      # Check if the user has a cooldown active
                      if user_id in self.cooldown_cache:
                          last_error_time = self.cooldown_cache[user_id]
                          if current_time - last_error_time < 3600:  # If within 10 seconds of the last cooldown error
                              return  # Skip sending another message
                          else:
                              # Update the last error time to prevent further cooldown message in the next 10 seconds
                              self.cooldown_cache[user_id] = current_time
                              return await self.context.reply(
                                  f"You're on cooldown! Please try again in {round(error.retry_after, 1)} seconds.", 
                                  mention_author=False
                              )
                      else:
                          # First time encountering cooldown, so we send the message and update the cache
                          self.cooldown_cache[user_id] = current_time
                          return await self.context.reply(
                              f"You're on cooldown! Please try again in {round(error.retry_after, 1)} seconds.", 
                              mention_author=False
                          )
                  else:
                      # For all other errors, handle them normally
                      return await super().on_help_command_error(ctx, error)

          async def command_not_found(self, string: str) -> None:
              with open('blacklist.json', 'r') as f:
                  bled = json.load(f)

              if str(self.context.author.id) in bled["ids"]:
                  user_id = str(self.context.author.id)
                  current_time = time.time()

                  # Prevent sending multiple DMs to blacklisted users
                  if user_id in self.cooldown_cache:
                      last_dm_time = self.cooldown_cache[user_id]
                      if current_time - last_dm_time < 3600:  # If within 60 seconds, skip sending the DM
                          return  # Skip sending another DM

                  # DM the user once and set cooldown cache
                  embed = discord.Embed(
                      title="<:Ban:1300389117678325813> Blacklisted",
                      description="You are blacklisted from using my commands.\nIf you think this is a mistake, you can appeal in our support server by clicking [here](https://discord.gg/reaperengine)",
                      color=0x00FFCA
                  )
                  try:
                      await self.context.author.send(embed=embed)
                      self.cooldown_cache[user_id] = current_time  # Set cooldown to prevent multiple DMs
                  except discord.Forbidden:
                      pass  # If the user has DMs disabled, we silently fail

                  # Send a message in the channel to let others know
                  await self.context.reply(
                      "You are blacklisted from using my commands. Please check your DMs for more information.",
                      mention_author=False
                  )
                  return
              else:
                  if string in ("security", "anti", "antinuke"):
                      cog = self.context.bot.get_cog("Antinuke")
                      with suppress(discord.HTTPException):
                          await self.send_cog_help(cog)
                  else:
                      msg = f"Command `{string}` is not found...\n"
                      rafi = await self.context.bot.fetch_user(1180115615114068020)
                      cmds = (str(cmd) for cmd in self.context.bot.walk_commands())
                      mtchs = get_close_matches(string, cmds)
                      if mtchs:
                          for okaay, okay in enumerate(mtchs, start=1):
                              msg += f"Did You Mean: \n`[{okaay}]` $`{okay}`\n"
                      return msg

          async def send_bot_help(self, mapping):
              with open('ignore.json', 'r') as heck:
                  randi = json.load(heck)
              with open('blacklist.json', 'r') as f:
                  bled = json.load(f)

              if str(self.context.author.id) in bled["ids"]:
                  embed = discord.Embed(
                      title="<:Ban:1300389117678325813> Blacklisted",
                      description="You are blacklisted from using my commands.\nIf you think this is a mistake, you can appeal in our support server by clicking [here](https://discord.gg/3Khp9KedDq)",
                      color=0x00FFCA
                  )
                  try:
                      await self.context.author.send(embed=embed)
                      await self.context.reply(
                          "You are blacklisted from using my commands. Please check your DMs for more information.",
                          mention_author=False
                      )
                  except discord.Forbidden:
                      pass
                  return
              elif str(self.context.channel.id) in randi["ids"]:
                  return None

              message = await self.context.reply(embed=discord.Embed(color=0x2f3136, description="<a:aloading:1300389194689941535> **Loading Help command...**"))
              data = getConfig(self.context.guild.id)
              prefix = data["prefix"]

              filtered = await self.filter_commands(self.context.bot.walk_commands(), sort=True)

              embed = discord.Embed(
                  title="Help Command Overview",
                  description=f"**• Prefix for this server is `{prefix}`\n •  Total Commands : {len(set(filtered))}\n• Type `{prefix}help <command | module>` for more",
                  color=0x2C2F33
              )
              embed.add_field(name="**__Main Modules__**", value="""**<:ExoticAntinuke:1303694752046383168> AntiNuke
              <:team:1300389303121215553> General
              <:stolen_emoji:1300672892933111920> Moderation
              <:Custom:1300393376788774985> Extra
              <:Add:1300389099391418428> Roles
              <:greet:1303696597653258280> Welcomer
              <:Unmute:1300389131133779978> VcRoles**""", inline=True)
              embed.set_thumbnail(url=self.context.bot.user.display_avatar.url)
              embed.set_footer(text="Justice Got More Power", icon_url="https://cdn.discordapp.com/attachments/1303633697768996866/1303657618669309962/03df25f26f7d021fb90a8148f820feca.png")
              embed.set_author(name=self.context.author.name, icon_url=self.context.author.display_avatar.url)
              embed.set_image(url="https://cdn.discordapp.com/attachments/1303633697768996866/1303656509041016904/a_a3aac522a2678ac80758e5a5096dc649.gif")
              embed.timestamp = discord.utils.utcnow()

              view = vhelp.View(mapping=mapping, ctx=self.context, homeembed=embed, ui=0)
              BB = await message.edit(embed=embed, view=view)
              view.message = BB
              view.emb = embed

          async def send_command_help(self, command):
              with open('ignore.json', 'r') as heck:
                  randi = json.load(heck)
              with open('blacklist.json', 'r') as f:
                  data = json.load(f)

              if str(self.context.author.id) in data["ids"]:
                  embed = discord.Embed(
                      title="<:Ban:1300389117678325813> Blacklisted",
                      description="You are blacklisted from using my commands.\nIf you think this is a mistake, you can appeal in our support server by clicking [here](https://discord.gg/3Khp9KedDq)",
                      color=0x00FFCA
                  )
                  try:
                      await self.context.author.send(embed=embed)
                      await self.context.reply(
                          "You are blacklisted from using my commands. Please check your DMs for more information.",
                          mention_author=False
                      )
                  except discord.Forbidden:
                      pass
                  return
              elif str(self.context.channel.id) in randi["ids"]:
                  return None
              else:
                  rafi = f">>> {command.help}" if command.help else '>>> No Help Provided...'
                  embed = discord.Embed(
                      description=f"""```yaml\n- [] = optional argument\n- <> = required argument\n- Do NOT Type These When Using Commands !```\n{rafi}""",
                      color=0x00FFCA
                  )
                  alias = ' | '.join(command.aliases)
                  embed.add_field(name="**Aliases**", value=f"{alias}" if command.aliases else "No Aliases", inline=False)
                  embed.add_field(name="**Usage**", value=f"`{self.context.prefix}{command.signature}`\n")
                  embed.set_author(name=f"{command.cog.qualified_name.title()}", icon_url=self.context.bot.user.display_avatar.url)
                  await self.context.reply(embed=embed, mention_author=False)

          async def send_cog_help(self, cog):
              with open('blacklist.json', 'r') as f:
                  data = json.load(f)
              with open('ignore.json', 'r') as heck:
                  randi = json.load(heck)

              if str(self.context.author.id) in data["ids"]:
                  embed = discord.Embed(
                      title="<:Ban:1300389117678325813> Blacklisted",
                      description="You are blacklisted from using my commands.\nIf you think this is a mistake, you can appeal in our support server by clicking [here](https://discord.gg/3Khp9KedDq)",
                      color=0x00FFCA
                  )
                  try:
                      await self.context.author.send(embed=embed)
                      await self.context.reply(
                          "You are blacklisted from using my commands. Please check your DMs for more information.",
                          mention_author=False
                      )
                  except discord.Forbidden:
                      pass
                  return
              elif str(self.context.channel.id) in randi["ids"]:
                  return None
              else:
                  entries = [(
                      f"`{self.context.prefix}{cmd.qualified_name}`",
                      f"{cmd.short_doc if cmd.short_doc else 'No Description Provided...'}\n\n"
                  ) for cmd in cog.get_commands()]
              paginator = Paginator(source=FieldPagePaginator(
                  entries=entries,
                  title=f"{cog.qualified_name.title()} ({len(cog.get_commands())})",
                  description="```yaml\n- [] = optional argument\n- <> = required argument\n- Do NOT Type These When Using Commands !```\n\n",
                  color=0x00FFCA,
                  per_page=10),
                                  ctx=self.context)
              await paginator.paginate()





class Help(Cog, name="help"):

  def __init__(self, client: Astroz):
    self._original_help_command = client.help_command
    attributes = {
      'name':
      "help",
      'aliases': ['h'],
      'cooldown':
      commands.CooldownMapping.from_cooldown(1, 5, commands.BucketType.user),
      'help':
      'Shows help about bot, a command or a category'
    }
    client.help_command = HelpCommand(command_attrs=attributes)
    client.help_command.cog = self

  async def cog_unload(self):
    self.help_command = self._original_help_command
