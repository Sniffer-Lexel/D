import discord
from discord.ext import commands


class general1(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    """General Commands"""
  
    def help_custom(self):
		      emoji = '<:team:1300389303121215553>'
		      label = "General"
		      description = "Show You Commands Of General"
		      return emoji, label, description

    @commands.group()
    async def __General__(self, ctx: commands.Context):
        """`purge` , `mute` , `kick` , `ban` , `unban` , `warn` , `lock` , `unlock`, `afk` , `av` , `banner` , `mc` , `nick` , `wizz` , `about` , `status` , `embed` , `verification` , `gstart` , `logging` , `autorole` , `greet`"""