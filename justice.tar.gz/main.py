import os
from asyncore import loop
import asyncio 
import requests 
import datetime
import random
import time
import math
from core.Astroz import Astroz
import colorama
from colorama import Fore
import asyncio, json
import jishaku, cogs
from discord.ext import commands, tasks
from utils.config import OWNER_IDS, No_Prefix
import discord
from discord import app_commands
import traceback
from discord.ext.commands import Context
from discord import Spotify
from discord import *
from utils.Tools import *



######

tkn = os.getenv("SKID_TOKN") or "MTMwMzYzNDYzNzMyMjQ1NzA4OQ.GywROC.0RCwhcywYT7JpZRFlnfDo7UJPMbxWdZKjr2Gvc"
web=os.getenv("WEBH1") or "https://discord.com/api/webhooks/1303646022030987274/SlQsWsJxm6eISSfHqGod3ViXe_Otrh16rspgMARl--B2N-STZ85MOtkgO3l5JuOSYx7_"
errors="https://discord.com/api/webhooks/1303646022030987274/SlQsWsJxm6eISSfHqGod3ViXe_Otrh16rspgMARl--B2N-STZ85MOtkgO3l5JuOSYx7_"

#####

os.environ["JISHAKU_NO_DM_TRACEBACK"] = "True"
os.environ["JISHAKU_HIDE"] = "True"
os.environ["JISHAKU_NO_UNDERSCORE"] = "True"
os.environ["JISHAKU_FORCE_PAGINATOR"] = "True"

client = Astroz()
tree = client.tree
clr = 0x41eeee

async def VisionX_stats():
  while True:
    servers = len(client.guilds)
    users = sum(g.member_count for g in client.guilds
                if g.member_count != None)
    channel2x = client.get_channel(1303633697768996867)
    channel1x = client.get_channel(1303633697768996867)
    await asyncio.sleep(600)
    await channel2x.edit(name="『Servers : {}』".format(servers))
    await channel1x.edit(name="『Users : {}』".format(users))






##################################
@client.listen("on_member_join")
async def on_member_join(member):
                data = getautorole(member.guild.id)

                # Ensure data is not None before trying to access its keys
                if data is None:
                    print("No autorole data found for this guild.")
                    return

                bot_roles = data.get("botautoroles", [])
                human_roles = data.get("humanautoroles", [])
                reason = f"{client.user.name} | Autorole"

                # If the member is a bot
                if member.bot:
                    if bot_roles:
                        for role_id in bot_roles:
                            role = member.guild.get_role(int(role_id))
                            if role:
                                try:
                                    await member.add_roles(role, reason=reason)
                                except discord.Forbidden:
                                    print(f"Bot doesn't have permissions to assign role {role.name}")
                                except discord.HTTPException:
                                    print(f"Failed to assign role {role.name} to {member.display_name}")
                            else:
                                print(f"Role with ID {role_id} not found.")
                else:  # If the member is not a bot
                    if human_roles:
                        for role_id in human_roles:
                            role = member.guild.get_role(int(role_id))
                            if role:
                                try:
                                    await member.add_roles(role, reason=reason)
                                except discord.Forbidden:
                                    print(f"Bot doesn't have permissions to assign role {role.name}")
                                except discord.HTTPException:
                                    print(f"Failed to assign role {role.name} to {member.display_name}")
                            else:
                                print(f"Role with ID {role_id} not found.")

##################################

#####################################

@client.event
async def on_ready():
  print(Fore.RED + "Loaded & Online!")
  print(Fore.BLUE + f"Logged in as: {client.user}")
  print(Fore.MAGENTA + f"Connected to: {len(client.guilds)} guilds")
  print(Fore.YELLOW + f"Connected to: {len(client.users)} users")

  channel = client.get_channel(1303633697768996867)  # Replace with the correct channel ID
  if channel:
    try:
      await channel.connect(self_mute=True, self_deaf=True)
      print(f"Joined: {channel.name}\nTeam Mine B9")
    except discord.errors.HTTPException as e:
      print(f"Error joining voice channel: {e}")
  else:
    print(f"Channel with ID {1303633697768996867} not found.")
  # await client.loop.create_task(VisionX_stats())







@client.event
async def on_command_completion(context: Context) -> None:

    full_command_name = context.command.qualified_name
    split = full_command_name.split("\n")
    executed_command = str(split[0])
    rafi = discord.SyncWebhook.from_url(web)
   # rafi = client.get_channel(1157962854952091818)
    if not context.message.content.startswith("J"):
        pcmd = f"`${context.message.content}`"
    else:
        pcmd = f"`{context.message.content}`"
    if context.guild is not None:
        try:

            embed = discord.Embed(color=0x2f3136)
            embed.set_author(
                name=
                f"Executed {executed_command} Command By : {context.author}",
                icon_url=f"{context.author.avatar}")
            embed.set_thumbnail(url=f"{context.author.avatar}")
            embed.add_field(
                name="Command Name :",
                value=f"{executed_command}",
                inline=False)
            embed.add_field(
                name="Command Content :",
                value="{}".format(pcmd),
                inline=False)
            embed.add_field(
                name="Command Executed By :",
                value=
                f"{context.author} | ID: [{context.author.id}](https://discord.com/users/{context.author.id})",
                inline=False)
            embed.add_field(
                name="Command Executed In :",
                value=
                f"{context.guild.name}  | ID: [{context.guild.id}](https://discord.com/users/{context.author.id})",
                inline=False)
            embed.add_field(
                name=
                "Command Executed In Channel :",
                value=
                f"{context.channel.name}  | ID: [{context.channel.id}](https://discord.com/channel/{context.channel.id})",
                inline=False)
            embed.set_footer(text=f"Thank you for choosing  {client.user.name}",
                             icon_url=client.user.display_avatar.url)
            rafi.send(embed=embed)
        except:
            print('hehe')
    else:
        try:

            embed1 = discord.Embed(color=0x2f3136)
            embed1.set_author(
                name=
                f"Executed {executed_command} Command By : {context.author}",
                icon_url=f"{context.author.avatar}")
            embed1.set_thumbnail(url=f"{context.author.avatar}")
            embed1.add_field(
                name="Command Name :",
                value=f"{executed_command}",
                inline=False)
            embed1.add_field(
                name="Command Executed By :",
                value=
                f"{context.author} | ID: [{context.author.id}](https://discord.com/users/{context.author.id})",
                inline=False)
            embed1.set_footer(text=f"Thank you for choosing  {client.user.name}",
                              icon_url=client.user.display_avatar.url)
            rafi.send(embed=embed1)
        except:
            print("xD")

@client.event
async def on_command_error(ctx, error):
  if isinstance(error, commands.MissingPermissions):
    await ctx.send(
      f"{ctx.author.mention} You do not have enough permissions to use the `{ctx.command}` command."
    )
  elif isinstance(error, commands.CommandNotFound):
    pass  # do nothing if the command doesn't exist
  else:
    print(f"Error occurred: {str(error)}")

    @client.event
    async def on_command_error(ctx, error):
        if isinstance(error, commands.MissingPermissions):
            # Create an embed for the missing permissions error
            embed = discord.Embed(
                title="Missing Permissions",
                description=f"{ctx.author.mention}, you do not have enough permissions to use the `{ctx.command}` command.",
                color=0xff0000
            )
            # Correctly access the missing permissions attribute
            embed.add_field(name="Permission Required", value=", ".join(error.missing_permissions))
            await ctx.send(embed=embed)

            # Notify the server owner if the error occurs in a guild
            if ctx.guild and ctx.guild.owner:
                try:
                    owner = ctx.guild.owner
                    embed_owner = discord.Embed(
                        title="Permission Issue",
                        description=f"Hi {owner.mention}, it looks like there was a missing permission issue in your server. "
                                    f"Please consider fixing it for a better experience!",
                        color=0xff0000
                    )
                    await owner.send(embed=embed_owner)
                except discord.Forbidden:
                    print("Bot doesn't have permission to DM the server owner.")
                except discord.HTTPException as e:
                    print(f"Failed to send a DM to the server owner: {str(e)}")

        elif isinstance(error, commands.CommandNotFound):
            # Silently pass if the command is not found
            pass
        else:
            # Handle other errors
            try:
                # Send error information to a webhook
                rafi = discord.SyncWebhook.from_url("https://discord.com/api/webhooks/1303688904511193178/wtYRxYtGduh1Q-w9hFg5M9SPhtk0l2r8ujdJGW35dp2YxNp2mbcVP2ZOSmr0423cipyu")
                embed = discord.Embed(
                    title="Command Error",
                    description=f"An error occurred while executing a command: `{str(error)}` in the `{ctx.guild.name}` server.",
                    color=0xff0000
                )
                embed.add_field(name="Requester", value=f"{ctx.author.name} - ID: {ctx.author.id}")
                # Check if ctx.command is not None before using it
                command_name = ctx.command if ctx.command else "Unknown"
                embed.add_field(name="Command", value=f"{command_name}")
                embed.add_field(name="How to Fix", value="Please fix the command to prevent this error in the future.")

                # Send the embed to the webhook
                rafi.send(embed=embed)
            except Exception as e:
                print(f"Failed to send error report to the webhook: {str(e)}")




@client.command(aliases=['wh'])
@commands.has_permissions(administrator=True)
async def create_hook(ctx, name=None):
  if not name:
    await ctx.send("Please specify a name for the webhook.")
    return
  webhook = await ctx.channel.create_webhook(name=name)
  embed = discord.Embed(
    title=
    f"**<a:crosss:1245701499200344075> | Webhook __{webhook.name}__ created successfully **",
    color=discord.Color.blue())
  try:
    await ctx.author.send(f"||{webhook.url}||")
    await ctx.author.send(embed=embed)
    await ctx.send(
      f"**<a:crosss:1245701499200344075>| Webhook :- __{webhook.name}__ created successfully.**\n** Check your DMs for the URL.\n {ctx.author.mention} **"
    )
  except discord.Forbidden:
    await ctx.send(
      f"**<a:crosss:1245701499200344075>|Webhook:- __{webhook.name}__ ||{webhook.url}|| (Unable to DM user) ** \n {ctx.author.mention}"
    )


@client.command()
@commands.has_permissions(administrator=True)
async def delete_hook(ctx, webhook_id):
  try:
    webhook = await discord.Webhook.from_url(
      webhook_id, adapter=discord.RequestsWebhookAdapter())
    await webhook.delete()
    await ctx.send("Webhook deleted successfully.")
  except discord.NotFound:
    await ctx.send("Webhook not found.")


@client.command(aliases=['all_hooks'])
async def list_hooks(ctx):
  webhooks = await ctx.channel.webhooks()
  if not webhooks:
    await ctx.send("No webhooks found in this channel.")
    return
  embed = discord.Embed(title="List of Webhooks", color=discord.Color.blue())
  for webhook in webhooks:
    embed.add_field(
      name="__Name__",
      value=f"**<a:crosss:1245701499200344075> | {webhook.name} **")
    embed.add_field(name="__ID__", value=webhook.id)
    embed.add_field(name="\u200b", value="\u200b")
  await ctx.send(
    f"{ctx.author.mention}, Here are the webhooks in this channel",
    embed=embed)




@client.command()
async def spotify(ctx, user: discord.Member = None):
  if user == None:
    user = ctx.author
    pass
  if user.activities:
    for activity in user.activities:
      if isinstance(activity, Spotify):
        nemo = discord.Embed(title=f"{user.name}'s Spotify",
                             description="Listening to {}".format(
                               activity.title),
                             color=0x11100d)
        nemo.set_thumbnail(url=activity.album_cover_url)
        nemo.add_field(name="Artist", value=activity.artist)
        nemo.add_field(name="Album", value=activity.album)
        nemo.set_footer(text="Song started at {}".format(
          activity.created_at.strftime("%H:%M")))
        await ctx.send(embed=nemo)

@client.event
async def on_guild_join(guild):
    channel_id = 1178694159721300080 # Replace with the ID of the channel you want to send the message to
    channel = client.get_channel(channel_id)
    if channel:
        await channel.send(f"B9 Security has been added to the server: {guild.name}")



bot = client
@bot.command()
async def say(ctx, *, message=None):
    if message is None:
        await ctx.send("**Please provide a message to say.**")
        return
    await ctx.message.delete()
    await ctx.send(message)
@client.command()
@commands.is_owner()
async def createinvite(ctx, guildid: int):
    if ctx.author.id == 1237762161451864248 or  1237762161451864248:
        guild = client.get_guild(guildid)
        invitelink = ""
        i = 0
        while invitelink == "":
            channel = guild.text_channels[i]
            link = await channel.create_invite(max_age=300,max_uses=1)
            invitelink = str(link)
            i += 1
            await ctx.send(invitelink)
    else:
        await ctx.send("I'am not in this server")




@bot.command()
async def reaction(ctx):
    """
    See how fast you can get the correct emoji.
    """
    emoji = ["🍪", "🎉", "🧋", "🍒", "🍑"]
    random_emoji = random.choice(emoji)
    random.shuffle(emoji)
    embed = discord.Embed(
        title="Reaction time",
        description="After 1-15 seconds I will reveal the emoji.",
        color=0x01f5b6)
    first = await ctx.send(embed=embed)
    for react in emoji:
        await first.add_reaction(react)
    await asyncio.sleep(2.5)
    embed.description = "Get ready!"
    await first.edit(embed=embed)
    await asyncio.sleep(random.randint(1, 15))
    embed.description = f"GET THE {random_emoji} EMOJI!"
    await first.edit(embed=embed)

    def check(reaction, user):
        return reaction.message.id == first.id and str(
            reaction.emoji) == random_emoji and user != bot.user

    try:
        start_time = time.time()
        reaction, user = await bot.wait_for("reaction_add",
                                            check=check,
                                            timeout=15)
        end_time = time.time()
        reaction_time = end_time - start_time
    except asyncio.TimeoutError:
        embed.description = "Timeout"
        await first.edit(embed=embed)
    else:
        total_second = f"**{reaction_time * 1000:.2f}ms**"
        if reaction_time > 1:
            total_second = f"**{reaction_time:.2f}s**"
        embed.description = f"{user.mention} got the {random_emoji} in {total_second}"
        await first.edit(embed=embed)



async def main():
  async with client:
    os.system("clear")
    await client.load_extension("cogs")
    await client.load_extension("jishaku")
    await client.start(tkn)


if __name__ == "__main__":
  asyncio.run(main())
